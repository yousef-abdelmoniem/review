package com.jan;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Scanner;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Enroll {
	private static final char[] object1 = null;
	public Enroll() {}
	public void createStudentRecord() {
		Student s = new Student();
		Course c = new Course();
		JSONObject object = new JSONObject();
		JSONArray array = new JSONArray();
		File file1 = new File("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\studentenroll.json");
		try {
			FileWriter writer = new FileWriter(file1);
			System.out.println("Enter your id");
			object.put("Student id", s.getId());
			System.out.print("Enter courses id");
			for(int i = 1 ;i<=6;i++) {
				//maximum is 6 courses
//				if(c.getId()=)
				array.add(c.getId());
			}
			object.put("Courses ids", array);
			System.out.print(object.toJSONString());
			 try (PrintWriter out = new PrintWriter(writer)) {
					out.println(object);
					}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void removeCourseJson() {
		JSONObject object1 =new JSONObject();
		Student s = new Student();
		Course c = new Course();
//		String IDnumber=s.getId();
		JSONParser parser = new JSONParser();
		try {
			Scanner sc= new Scanner(System.in);
			String unwantedcourse=sc.next();
			File file1 = new File("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\studentenroll.json");
			FileWriter writer = new FileWriter(file1);
			Object x = parser.parse(new FileReader("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\studentenroll.json"));
			JSONObject Object = (JSONObject)x;
			System.out.print(Object);
			String id = (String) Object.get("Student id");
			JSONArray courses =(JSONArray)Object.get("Courses ids");
			for(int i = 1;i<6;i++) { //max courses to be removed is 2
				if(unwantedcourse.equals(courses.get(i))){
					courses.remove(i);
					System.out.println("course removed"+ courses.get(i));
					
				}
				
				
				
			}
			System.out.print(courses);
//			object1.put("Student id",id);
//			object1.put("Courses ids",courses);
//			try (PrintWriter out = new PrintWriter(writer)) {
//				out.println(object1);
//				}
//			System.out.print(id);
//			System.out.print(courses);
		} catch (IOException | ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
