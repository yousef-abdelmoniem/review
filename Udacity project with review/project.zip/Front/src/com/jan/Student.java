package com.jan;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Scanner;

public class Student {
	
	private int id=0;
	private String name = "";
	private int grade=0;
	private String email="";
	private String adress="";
	private String region="";
	private String country="";
	public Student(String name , int id , String email, int grade, String adress, String region ,String country) {
		this.name=name;
		this.id=id;
		this.grade=grade;
		this.email=email;
		this.adress=adress;
		this.region=region;
		this.country=country;
		
	}
	public Student() {
		// TODO Auto-generated constructor stub
	}
	public String[] getCsv() throws IOException {
		Scanner sc =new Scanner(System.in);
		id=sc.nextInt();
		String [] student = null;
		String remove = ",";
		if(id>100)
			System.out.println("invalid id");
		String line = Files.readAllLines(Paths.get("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\data.csv")).get(id);
		student = line.split(remove);   
		System.out.println("student id:" + student[0] + ", name: " + student[1] + ", grade: " + student[2] + ", email: " + student[3] + ", adress: " + student[4] + ", country: " + student[5] +", region: " + student[6]);  
		return student;
		
		
	}
	public String getId() {
		String[] a = null;
		try {
			a = getCsv();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String id=a[0];
//		System.out.print("id: "+id);
		return id;
	}
	
	public String getName() {
		String[] a = null;
		try {
			a = getCsv();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String NAME=a[1];
		System.out.print("name: "+name);
		return NAME;
	}
	
	public String getGrade() {
		String[] a = null;
		try {
			a = getCsv();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String grade=a[2];
		System.out.print("grade: "+grade);
		return grade;
	}
	
	public String getEmail() {
		String[] a = null;
		try {
			a = getCsv();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String id=a[3];
		System.out.print("email: "+email);
		return email;
	}
	
	public String getAdress() {
		String[] a = null;
		try {
			a = getCsv();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String adress=a[4];
		System.out.print("adress: "+adress);
		return adress;
	}
	
	public String getRegion() {
		String[] a = null;
		try {
			a = getCsv();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String region=a[6];
		System.out.print("id: "+region);
		return region;
	}
	public String getCountry() {
		String[] a = null;
		try {
			a = getCsv();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String country=a[5];
		System.out.print("country: "+country);
		return country;
	}
	public void sudentData() {
		String[] students;
		File file=new File("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\data.csv");
		String line="";
		String remove=",";
		Scanner sc = new Scanner(System.in);
		try {
			sc=new Scanner(file);
			while(sc.hasNext()) {
				students=sc.nextLine().split(remove);
				System.out.println(Arrays.toString(students));
				
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}
	

}
