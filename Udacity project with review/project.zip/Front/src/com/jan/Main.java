package com.jan;
import java.io.File;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.json.simple.parser.ParseException;
public class Main {

	public static void main(String[] args) throws IOException, ParserConfigurationException, ParseException {
		FileOperations x =new FileOperations();
		File file1 = new File("src\\coursedata.xml");
		File file2=new File("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\data.csv");
		File file=new File("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\scd.json");

//		x.createCSVfromXML(file1);
//		GenerateCsvData c = new GenerateCsvData();
//		c.listData(file2);
//		CreateJsonFile v =new CreateJsonFile();
//		v.goJson();
//		v.removeDuplictae();
//		ReadJson read = new ReadJson();
//		read.getData();
////		
//		Student s1=new Student();
//		s1.getCsv();
//		s1.getId();
//		s1.sudentData();
//		Course c = new Course();
//		c.getCoursename();
//		c.readJson();
		Enroll e1 = new Enroll();
		e1.createStudentRecord();
//		e1.removeCourseJson();
//		

	}

}
