package com.jan;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Array;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


public class ReadJson  {
	@SuppressWarnings("unchecked")
	public void getData() throws IOException {
		
		@SuppressWarnings("deprecation")
		Student s = new Student();
		Course c = new Course();
		JSONParser parser = new JSONParser();
		
		try {
			
		
			@SuppressWarnings("deprecation")
			Object x = parser.parse(new FileReader("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\studentcoursedata2.json"));
			System.out.println("please enter ID number");
//			Scanner sc = new Scanner(System.in);
//			String IDnumber = sc.next();
			System.out.println("===============================================================================================");
			System.out.println("Student Details page");
			System.out.println("===============================================================================================");
			String IDnumber=s.getId();
			System.out.println("-----------------------------------------------------------------------------------------------");
			System.out.println("Enrolled courses.");
			System.out.println("=================");
			int []ids=new int[5];
			JSONObject Object = (JSONObject)x;
			JSONObject id = (JSONObject) Object.get(IDnumber);
			@SuppressWarnings("deprecation")
			JSONArray courses =(JSONArray)id.get("courses");
	        Iterator<Object>iterator=courses.iterator();
	        int i = 0;
	        
	        while(iterator.hasNext()) {
	        	
	        	Number num = (Number) (iterator.next());
	            ids[i] = num.intValue();
	        	String [] courses1 = null;
	    		String remove = ",";
	    		String line = Files.readAllLines(Paths.get("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\course.csv")).get(ids[i]);
	    		courses1 = line.split(remove);   
	    		System.out.println("id:" + courses1[0] + ", coursename: " + courses1[1] + ", instructor: " + courses1[2]+courses1[3] + ", courseduration " + courses1[4] + ", coursetime: " + courses1[5] + ", location: " + courses1[6]);  
	    		System.out.println("-----------------------------------------------------------------------------------------------");
	    		i++;
	    		
	        	}
	        
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(NullPointerException e) {
			e.printStackTrace();
		}


		
		}
	
	}

