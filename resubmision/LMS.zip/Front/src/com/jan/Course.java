package com.jan;
import java.util.regex.Pattern; 
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.Scanner;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;



public class Course {
	private int id;
	private String coursename="";
	private String instructor="";
	private String courseduration="";
	private String coursetime="";
	private String location="";
	
	public Course(int id,String coursename,String instructor,String courseduration,String coursetime,String location) {
		this.id=id;
		this.coursename=coursename;
		this.instructor=instructor;
		this.courseduration=courseduration;
		this.coursetime=coursetime;
		this.location=location;
		
	}
	public Course() {
		// TODO Auto-generated constructor stub
	}
	public String[] getCsv() throws IOException {
		Scanner sc =new Scanner(System.in);
		id=sc.nextInt();
		String [] courses = null;
		String remove = ",";
		String line = Files.readAllLines(Paths.get("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\course.csv")).get(id);
		courses = line.split(remove);   
		System.out.println("id:" + courses[0] + ", coursename: " + courses[1] + ", instructor: " + courses[2]+courses[3] + ", courseduration " + courses[4] + ", coursetime: " + courses[5] + ", location: " + courses[6]);  
		return courses;
		
		
	}

	public String getId() {
		String[] a = null;
		try {
			a = getCsv();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String id=a[0];
		System.out.print("id: "+id);
		return id;
	}

	
	public String getCoursename() {
		String[] a = null;
		try {
			a = getCsv();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String coursename=a[1];
		System.out.print("coursename: "+coursename);
		return coursename;
	}


	public String getInstructor() {
		String[] a = null;
		try {
			a = getCsv();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String instructor=a[2];
		String instructot1=a[3];
		
		System.out.print("Instructor: "+instructor+","+instructot1);
		return instructor;
	}

	

	public String getCourseduration() {
		String[] a = null;
		try {
			a = getCsv();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String courseduration=a[4];
		System.out.print("id: "+courseduration);
		return courseduration;
	}


	public String getCoursetime() {
		String[] a = null;
		try {
			a = getCsv();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String coursetime=a[5];
		System.out.print("id: "+coursetime);
		return coursetime;
	}


	public String getLocation() {
		String[] a = null;
	try {
		a = getCsv();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	String location=a[6];
	System.out.print("id: "+location);
		return location;
	}
	public String[] courseList() throws IOException {
		int id = 1;
		int i= 0;
		String [] course =new String[99];
		String remove = ",";
		while(id<18){
		String line = Files.readAllLines(Paths.get("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\course.csv")).get(id);
		course[i]=line;
		i++;
		id++;
		
		}
//		System.out.println("student id:" + student[0] + ", name: " + student[1] + ", grade: " + student[2] + ", email: " + student[3] + ", adress: " + student[4] + ", country: " + student[5] +", region: " + student[6]);  
		return course;
		
	}
//public String toString() {
//	return ;
	
}
		

		
