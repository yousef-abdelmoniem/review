package com.jan;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Gui extends JFrame implements ActionListener {
	JFrame frame;
	JComboBox combo;
	JLabel choice;
	JLabel label12;
	JButton button1;
	JButton button2;
	JButton button3;
	JButton button4;
	JFrame frame2;
	JComboBox student;
	JComboBox courses;
	JComboBox courses2;
	JComboBox courses3;
	JComboBox courses4;
	JComboBox courses5;
	JLabel sc;
	JLabel cc1;
	JLabel cc2;
	JLabel cc3;
	JLabel cc4;
	JLabel cc5;
	JLabel msg;
	JButton b1;
	JButton b2;
	JButton b3;
	
	public void createFrame() throws IOException {
		
		JLabel label1 = new JLabel();
		JLabel label2 = new JLabel();
		JLabel label3 = new JLabel();
		JLabel label4 = new JLabel();
		JLabel label5 = new JLabel();
		JLabel label6 = new JLabel();
		JLabel label7 = new JLabel();
		JLabel label8 = new JLabel();
		JLabel label9 = new JLabel();
		JLabel label10 = new JLabel();
		JLabel label11 = new JLabel();
		label12 = new JLabel();
		JLabel label13 = new JLabel();
		
		
		
		label1.setBounds(10,0,100,50);
		label2.setBounds(10, 10, 180, 80);
		label3.setBounds(10, 17, 600, 110);
		label4.setBounds(10, 24, 250, 140);
		label5.setBounds(10, 31, 600, 170);
		label6.setBounds(10, 38, 600, 200);
		label7.setBounds(10, 180, 650, 70);
		label8.setBounds(10, 190, 600, 80);
		label9.setBounds(10, 200, 600, 90);
		label10.setBounds(10, 225, 650, 100);
		label11.setBounds(10, 235, 600, 110);
		label12.setBounds(10, 245, 600, 120);
		label13.setBounds(10, 255, 650, 130);
		
		
		
		label1.setText("Welcome to LMS");
		label2.setText("Created by yousef mohamed");
		label3.setText("===============================================================================");
		label4.setText("Home Page");
		label5.setText("===============================================================================");
		label6.setText("Student List:");
		label7.setText("===============================================================================");
		label8.setText("Student Details page");
		label9.setText("===============================================================================");
		label10.setText("-------------------------------------------------------------------------------------------------------------------------------------------");
		label11.setText("Enrolled Courses");
		
		label13.setText("-------------------------------------------------------------------------------------------------------------------------------------------");
		
		Student s = new Student();
		String[] x= s.studentlist();
		button1=new JButton();
		button2=new JButton();
		button3=new JButton();
		button4=new JButton();
		button1.setText("Enroll in a course");
		button2.setText("Unenroll from an existing course");
		button3.setText("Replacing an existing course");
		button4.setText("Back to the main page");
		
		combo = new JComboBox(x);
		choice = new JLabel();
	
		combo.addActionListener(this);
		button1.addActionListener(this);
//		button2.addActionListener(this);
//		button3.addActionListener(this);
//		button4.addActionListener(this);
		combo.setBounds(10, 170, 650, 40);
		choice.setBounds(10, 215, 650, 100);
		button1.setBounds(10, 350, 300, 30);
		button2.setBounds(10, 400, 300, 30);
		button3.setBounds(10, 450, 300, 30);
		button4.setBounds(10, 500, 300, 30);
		
		
		frame = new JFrame();
		frame.setTitle("LMS");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		frame.setResizable(false);
		frame.setSize(1500, 700);
		frame.setVisible(true);
		frame.setLayout(null);
		frame.add(label1);
		frame.add(label2);
		frame.add(label3);
		frame.add(label4);
		frame.add(label5);
		frame.add(label6);
		frame.add(combo);
		frame.add(label7);
		frame.add(label8);
		frame.add(label9);
		frame.add(choice);
		frame.add(label10);
		frame.add(label11);
		frame.add(label12);
		frame.add(label13);
		frame.add(button1);
		frame.add(button2);
		frame.add(button3);
		frame.add(button4);
		
		ImageIcon image = new ImageIcon("LMS.JPG");
		frame.setIconImage(image.getImage());
		
		
		
		
	}
	public void createEnrollmentPage() throws IOException {
		JLabel text1 = new JLabel();
		JLabel text2 = new JLabel();
		msg= new JLabel();
		text1.setText("Students list:");
		text2.setText("Courses list:");
		text1.setBounds(10, 10, 180, 80);
		text2.setBounds(10, 70, 180, 80);
		Student s = new Student();
		Course c = new Course();
		student = new JComboBox(s.studentlist());
		courses = new JComboBox(c.courseList());
		courses2 = new JComboBox(c.courseList());
		courses3 = new JComboBox(c.courseList());
		courses4 = new JComboBox(c.courseList());
		courses5 = new JComboBox(c.courseList());
		
		b1=new JButton();
		b1.addActionListener(this);
		b2=new JButton();
		b2.addActionListener(this);
		b3=new JButton();
		b3.addActionListener(this);
		
		b1.setText("Save");
		b2.setText("Exit");
		b3.setText("Back");
		
		b1.setBounds(500,600, 100, 30);
		b2.setBounds(600,600, 100, 30);
		b3.setBounds(700,600, 100, 30);
		
		student.setBounds(90, 35, 650, 30);
		courses.setBounds(90, 100, 450, 20);
		courses2.setBounds(90, 175, 450, 20);
		courses3.setBounds(90, 250, 450, 20);
		courses4.setBounds(90, 325, 450, 20);
		courses5.setBounds(90, 400, 450, 20);
		
		student.addActionListener(this);
		courses.addActionListener(this);
		courses2.addActionListener(this);
		courses3.addActionListener(this);
		courses4.addActionListener(this);
		courses5.addActionListener(this);
		
		sc=new JLabel();
		cc1=new JLabel();
		cc2=new JLabel();
		cc3=new JLabel();
		cc4=new JLabel();
		cc5=new JLabel();
		
		sc.setBounds(90, 60, 650, 30);
		sc.setOpaque(true);
		cc1.setBounds(90, 120, 450, 30);
		cc2.setBounds(90, 195, 450, 30);
		cc3.setBounds(90, 270, 450, 30);
		cc4.setBounds(90, 345, 450, 30);
		cc5.setBounds(90, 420, 450, 30);
		
		cc1.setOpaque(true);
		cc2.setOpaque(true);
		cc3.setOpaque(true);
		cc4.setOpaque(true);
		cc5.setOpaque(true);
		msg.setOpaque(true);
		
		frame2 = new JFrame();
		frame2.setTitle("LMS");
		frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		frame.setResizable(false);
		frame2.setSize(1500, 700);
		frame2.setVisible(true);
		frame2.setLayout(null);
		frame2.add(text1);
		frame2.add(text2);
		frame2.add(student);
		frame2.add(courses);
		frame2.add(courses2);
		frame2.add(courses3);
		frame2.add(courses4);
		frame2.add(courses5);
		frame2.add(sc);
		frame2.add(cc1);
		frame2.add(cc2);
		frame2.add(cc3);
		frame2.add(cc4);
		frame2.add(cc5);
		frame2.add(msg);
		frame2.add(b1);
		frame2.add(b2);
		frame2.add(b3);
		ImageIcon image = new ImageIcon("LMS.JPG");
		frame2.setIconImage(image.getImage());
		
		
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==combo) {
			choice.setText((String) combo.getSelectedItem());
			label12.setText("The student hasn't enrolled in any course yet.");
			label12.setForeground(Color.red);
			
			
		}
		if(e.getSource()==button1) {
			frame.dispose();
			try {
				createEnrollmentPage();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}
		if(e.getSource()==student) {
			sc.setText((String) student.getSelectedItem());
			sc.setForeground(Color.BLACK);
			sc.setBackground(Color.GRAY);
		}
		
		if(e.getSource()==courses) {
			cc1.setText((String) courses.getSelectedItem());
			cc1.setForeground(Color.BLACK);
			cc1.setBackground(Color.LIGHT_GRAY);
			msg.setText("Course added successfully!");
			msg.setForeground(Color.RED);
			msg.setBounds(590, 120, 450, 30);
			
		}
		if(e.getSource()==courses2) {
			cc2.setText((String) courses2.getSelectedItem());
			cc2.setForeground(Color.BLACK);
			cc2.setBackground(Color.GRAY);
			msg.setText("Course added successfully!");
			msg.setForeground(Color.RED);
			msg.setBounds(590, 195, 450, 30);
			
		}
		if(e.getSource()==courses3) {
			cc3.setText((String) courses3.getSelectedItem());
			cc3.setForeground(Color.BLACK);
			cc3.setBackground(Color.LIGHT_GRAY);
			msg.setText("Course added successfully!");
			msg.setForeground(Color.RED);
			msg.setBounds(590, 270, 450, 30);
			
		}
		if(e.getSource()==courses4) {
			cc4.setText((String) courses4.getSelectedItem());
			cc4.setForeground(Color.BLACK);
			cc4.setBackground(Color.GRAY);
			msg.setText("Course added successfully!");
			msg.setForeground(Color.RED);
			msg.setBounds(590, 345, 450, 30);
			
		}
		if(e.getSource()==courses5) {
			cc5.setText((String) courses5.getSelectedItem());
			cc5.setForeground(Color.BLACK);
			cc5.setBackground(Color.LIGHT_GRAY);
			msg.setText("Course added successfully!");
			msg.setForeground(Color.RED);
			msg.setBounds(590, 420, 450, 30);
			
		}
		if(e.getSource()==b1) {
			JOptionPane.showMessageDialog(null,"Saved successfully","save",JOptionPane.INFORMATION_MESSAGE);
		}
		if(e.getSource()==b3) {
			frame2.dispose();
			try {
				createFrame();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		if(e.getSource()==b2) {
			frame2.dispose();
		}
		
		
	}

}
