package com.jan;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Random;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

@SuppressWarnings("deprecation")
public class CreateJsonFile {
	public CreateJsonFile() {}
	@SuppressWarnings("unchecked")
	public JSONArray generateRandomArray() {
		int max = 15;
		int min =1 ;
		Random rand = new Random();
		JSONArray array = new JSONArray();
		array.add((rand.nextInt(max-min)+min));
		array.add((rand.nextInt(max-min)+min));
		array.add((rand.nextInt(max-min)+min));
		array.add((rand.nextInt(max-min)+min));
		array.add((rand.nextInt(max-min)+min));		
		return array;
		
	}
	@SuppressWarnings({ "null", "unchecked" })
	
	public JSONObject removeDuplictae() {
		JSONObject arr = new JSONObject();
		int max = 15;
		int min =1 ;
		Random rand = new Random();
		JSONArray x = generateRandomArray();
		for(int j=0;j<x.size();j++) {
		for(int i = 0;i<x.size();i++) {
			if(i==j)
				continue;
			else if(x.get(j)==x.get(i)) {
				x.remove(j);
				x.add((rand.nextInt(max-min)+min));
				}
			
			}
		}
		
		arr.put("courses",x);
		
		return arr;
	}
	public void goJson() throws IOException, IndexOutOfBoundsException{
		File file1 = new File("C:\\Users\\Yusseif\\eclipse-workspace\\Front\\CSVs\\studentcoursedata2.json");
		FileWriter writer = new FileWriter(file1);
		JSONObject object = new JSONObject();
		JSONObject object1 = new JSONObject();
		JSONObject object2 = new JSONObject();
		
		for(int i= 1;i<=100;i++) {
			String cast=String.valueOf(i);
			JSONObject generated = removeDuplictae();
			generated.toJSONString();
	    	
	    	
//	    	System.out.print(generated);
	    	object.put(object1.put("id", cast),generated);
			
			
		}
		
	    System.out.println(object.toJSONString());
	    
	    
        try (PrintWriter out = new PrintWriter(writer)) {
				out.println(object);
				}
		
		
		
		
	}

	
}
